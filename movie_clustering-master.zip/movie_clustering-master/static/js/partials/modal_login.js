
  // Écoutez le clic sur le bouton "Sign Up / Sign In" et appelez la fonction openModal
 // document.addEventListener('DOMContentLoaded', function () {
//    var openModalButton = document.getElementById('openModalbutton');
//    if (openModalButton) {
 //     openModalButton.addEventListener('click', function () {
//        openModal_total('Sign in');
//      });
//    }
//  });
  
  
// Écoutez le clic sur le bouton de fermeture
//document.addEventListener('DOMContentLoaded', function () {
//    var closeModalButton = document.getElementById('closeModalButton');
//    if (closeModalButton) {
//      closeModalButton.addEventListener('click', function () {
//        closeModal_total('Sign in')
//      });
//    }
//  });


 // document.addEventListener('DOMContentLoaded', function () {
 //       var Button_sign_up = document.getElementById('signUp');
 //       if (Button_sign_up) {
 //         Button_sign_up.addEventListener('click', function () {
 //           closeModal_total(Button_sign_up.innerHTML);
 //           openModal_total(Button_sign_up.innerHTML);
 //         });
 //       }
 //     });




